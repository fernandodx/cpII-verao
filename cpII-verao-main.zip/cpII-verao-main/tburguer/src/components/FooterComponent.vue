<template>
    <div>
        <footer id="footer">
            <p>Construido por Filipe Pinheiro Brandão &copy; 2024</p>
        </footer>
    </div>
</template>

<script>
    export default {
        name: "FooterComponent"
    }

</script>

<style scoped>

#footer {
    height: 80px;
    background-color: #333;
    border-top: solid 3px darkgoldenrod;
    color: darkgoldenrod;
    display: flex;
    align-items: center;
    justify-content: center;


}


</style>