<template>
  <div class="about">
    <h1>SOBRE</h1>
  </div>
</template>
