/*Desafio 01 
Escreva uma função que retorne a soma entre dois números.*/

//Função de soma

function soma(n1, n2){

const soma = n1 + n2;

return soma;

}

//teste passando numeros como parametro

console.log(soma(2023, 2024));
